package com.Insurance.bean;

public class InsurancePolicy {
private long policy_Number;
private double policy_Premium;
private long account_Number;
public long getPolicy_Number() {
	return policy_Number;
}
public void setPolicy_Number(long policy_Number) {
	this.policy_Number = policy_Number;
}
public double getPolicy_Premium() {
	return policy_Premium;
}
public void setPolicy_Premium(double policy_Premium) {
	this.policy_Premium = policy_Premium;
}
public long getAccount_Number() {
	return account_Number;
}
public void setAccount_Number(long account_Number) {
	this.account_Number = account_Number;
}

}
