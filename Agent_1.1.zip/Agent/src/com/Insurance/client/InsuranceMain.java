package com.Insurance.client;

import java.util.Scanner;

import com.Insurance.bean.InsuranceBean;
import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.exception.InsuranceClaimException;
import com.Insurance.service.IInsurance;

public class InsuranceMain {
	static Scanner sc=new Scanner(System.in);
	static InsuranceBean insuranceBean=null;
	static InsuranceClaimBean claimBean=null;
	static IInsurance service=null;
public static void main(String[] args) {
	insuranceBean=new InsuranceBean();	
	
	claimBean=new InsuranceClaimBean();
	System.out.println("Enter the Claim Number");
	claimBean.setClaim_Number(sc.nextInt());
	System.out.println("Enter claim Reason");
	claimBean.setClaim_Reason(sc.next());
	System.out.println("Enter Accident Location");
	claimBean.setAccident_Location(sc.next());
	System.out.println("Enter Accident City");
	claimBean.setAccident_City(sc.next());
	System.out.println("Enter Accident State");
	claimBean.setAccident_State(sc.next());
	System.out.println("Enter Accident Zip");
	claimBean.setAccident_Zip(sc.nextLong());
	System.out.println("Enter Claim Type");
	claimBean.setClaim_Type(sc.next());
	System.out.println("Enter Policy Number");
	claimBean.setPolicy_Number(sc.nextInt());
	
		try {
			boolean result=service.validateDetails(claimBean);
			if (result) {
				int policy_Number =claimBean.getPolicy_Number();
			
			}
		} catch (InsuranceClaimException e) {
			
			e.printStackTrace();
		}
		
	
	
}
}
