package com.Insurance.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.Insurance.bean.InsuranceBean;
import com.Insurance.bean.InsuranceClaimBean;

public interface InsuranceDao {
	int getPolicy_Number(InsuranceClaimBean insuranceClaimBean) throws SQLException;
}
