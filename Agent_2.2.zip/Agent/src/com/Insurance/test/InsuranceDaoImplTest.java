package com.Insurance.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.dao.InsuranceDao;
import com.Insurance.dao.InsuranceDaoImpl;



public class InsuranceDaoImplTest {

	InsuranceDao dao=null;
	@Before
	public void setUp() {
		dao=new InsuranceDaoImpl();
	}

	@After
	public void tearDown() {
		dao = null;
	}
	
	@Test
	public void testGetPolicy_Number() {
		InsuranceClaimBean claimBean=new InsuranceClaimBean();
		claimBean.setClaim_Reason("accident");
		claimBean.setAccident_Location("ramanthapur");
		claimBean.setAccident_City("hyderabad");
		claimBean.setAccident_State("telengana");
		claimBean.setAccident_Zip(500013);
		claimBean.setPolicy_Number(1000101);
		
	}

}
