package com.Insurance.util;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.Insurance.dao.InsuranceDaoImpl;

public class DbConnectionTest {

	static InsuranceDaoImpl daoImpl=null;
	static Connection dbCon;
	@BeforeClass
	public static void initialise() {
		daoImpl = new InsuranceDaoImpl();
		dbCon=null;
	}
	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}
	
	@Test
	public void testGetConnection() throws IOException {
		Connection dbCon = DbConnection.getConnection();
		Assert.assertNotNull(dbCon);
	}
	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daoImpl = null;
		dbCon = null;
	}

}
