package com.Insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;


import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.exception.InsuranceClaimException;
import com.Insurance.util.DbConnection;


public class InsuranceDaoImpl implements  InsuranceDao {
static InsuranceClaimBean insuranceBean=null;
static Logger logger = Logger.getLogger(InsuranceClaimBean.class);
	@Override
	public InsuranceClaimBean getPolicy_Number(InsuranceClaimBean insuranceClaimBean) throws SQLException, InsuranceClaimException {
		logger.info("in getting enquiry details  mehtod..");
		Connection connection=null;
		PreparedStatement statement=null;
	
		
		try {
			 connection = DbConnection.getConnection();
			 statement=connection.prepareStatement(QueryMappers.insertQuery);
			 //statement.setInt(1, insuranceClaimBean.getClaim_Number());
			 statement.setString(1, insuranceClaimBean.getClaim_Reason());
			 statement.setString(2, insuranceClaimBean.getAccident_Location());
			 statement.setString(3, insuranceClaimBean.getAccident_City());
			 statement.setString(4, insuranceClaimBean.getAccident_State());
			 statement.setLong(5, insuranceClaimBean.getAccident_Zip());
			 statement.setString(6, insuranceClaimBean.getClaim_Type());
			 statement.setInt(7, insuranceClaimBean.getPolicy_Number());
			 
			 statement.executeUpdate();
			
		} catch (IOException e) {
			logger.error("in enquiry details method ex is: " + e.getMessage());
			throw new InsuranceClaimException(" sorry no details found");
		}
		return insuranceClaimBean ;		
		
		
	}

}
