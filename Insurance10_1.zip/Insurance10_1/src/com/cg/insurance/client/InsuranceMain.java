package com.cg.insurance.client;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;
import com.cg.insurance.service.IInsuranceService;
import com.cg.insurance.service.InsuranceServiceImpl;

public class InsuranceMain {
	static Scanner sc=new Scanner(System.in);
	static UserBean userbean=null;
	static ClaimBean claimBean=null;
	static PolicyBean policyBean=null;
	static AgentUserBean agentUserBean=null;
	static QuestionBean questionBean =null;
	static PolicyDetailsBean policyDetailsBean=null;
	static IInsuranceService iInsuranceService = null;
	static InsuranceServiceImpl insuranceServiceImpl = null;
	static List<PolicyDetailsBean> policyDetailsList =null;
	static Logger logger = Logger.getLogger(InsuranceMain.class);
public static void main(String[] args) throws ClassNotFoundException, Exception {
	
	PropertyConfigurator.configure("resources/log4j.properties");
	logger.info("log4j file loaded...");
	logger.info("inside main method");
	
	again:while(true) {
	userbean = new UserBean();
	String rolecode=null;
	System.out.println("Enter Your Credentials to use your facility: ");
	System.out.println("Enter your Username: ");
	userbean.setUsername(sc.next());
	System.out.println("Enter your Password: ");
	userbean.setPassword(sc.next());
	
	iInsuranceService = new InsuranceServiceImpl();
	try {
	rolecode=iInsuranceService.checkAccess(userbean);
	}
	catch (InsuranceClaimException e) {
		
		System.err.println(e.getMessage() + " \n Want to Try again..????(y/n)");
		//System.exit(0);
		String cond=sc.next();
		if(cond.equals("y")||cond.equals("Y")) {
		continue again;
		}else {
			System.exit(0);
		}
		
	}
	int option;
	switch (rolecode.toLowerCase()) {
	case "insured":
		
		while(true)
		{
				System.out.println("\n----------------Welcome User--------------------\n");
				System.out.println("1.Create Claim as per Your Policies.");						//done
				System.out.println("2.View Claim.");				//done
				System.out.println("3.Exit.\n");
				
				try {
					
					option = sc.nextInt();
					switch (option) {
					case 1:
							
							try {
								iInsuranceService = new InsuranceServiceImpl();
								insuranceServiceImpl = new InsuranceServiceImpl();
								policyBean = new PolicyBean();
								List<PolicyBean> policyList = new ArrayList<PolicyBean>();
								System.out.println("Enter your user name: ");
								String name = sc.next();
								if (!name.equals(userbean.getUsername())) {
									System.err.println("InValid username!!!!");

								} else {
									policyList = iInsuranceService.viewAllPolicies(name);
									if (!policyList.isEmpty()) {
										int policyNumber = 1;
										Iterator<PolicyBean> i = policyList.iterator();
										System.out.println("Policy List\tAccount Number\tPolicy Number\tPremium Amount");
										while (i.hasNext()) {
											
											policyBean = i.next();
											System.out.println(
													"    " + policyNumber + ".\t\t" + policyBean.getAccountNumber()
															+ "\t\t" + policyBean.getPolicyNumber() + "\t\t"
															+ policyBean.getPolicyPremium());
											policyNumber++;
										}
										
										
										
										
										
										System.out.println("\nSelect option for which You Want to Create Claim.");
										
										
										try {
											int check=sc.nextInt();
											if(check>0&&check<policyNumber) {
												int inc=1;
												Iterator<PolicyBean> i1 = policyList.iterator();
												while (inc<=check) {
													policyBean = i1.next();
													inc++;
												}
												//System.out.println(policyBean.getPolicyNumber());
//////////////////////////////////////////////here claim Creation will come/////////////////////////////////////////////////////////////////
												int weightage = 0;
												String str = null;
												String claimNo = null;
												String claimNumber = null;
												claimBean = new ClaimBean();
												System.out.println("Enter Details To avail Claim");
												
												System.out.println("Enter claim Reason");
												claimBean.setClaimReason(sc.next());
												System.out.println("Enter Accident Location");
												claimBean.setAccidentLocationStreet(sc.next());
												System.out.println("Enter Accident City");
												claimBean.setAccidentCity(sc.next());
												System.out.println("Enter Accident State");
												claimBean.setAccidentState(sc.next());
												System.out.println("Enter Accident Zip");
												claimBean.setAccidentZip(sc.next());
												System.out.println("Choose the below optoin to select the claim type");
												int key = 0;
												loop: do {
													try {

														System.out.println("1.Road Accident Claims");
														System.out.println("2.Medical Negligence Claims");
														System.out.println("3.Trip Accident Claims");

														key = sc.nextInt();
														switch (key) {
														case 1:
															str = "Road Accident Claims";
															claimBean.setClaimType(str);

															break;
														case 2:
															str = "Medical Negligence Claims";
															claimBean.setClaimType(str);

															break;
														case 3:
															str = "Trip Accident Claims";
															claimBean.setClaimType(str);

															break;
														default:

															System.out.println("Please enter from the above options again");
															break;
														}

													} catch (InputMismatchException e) {
														System.out.println(e.getMessage());
														System.out.println("try again...");
														sc.nextLine();
														continue loop;

													}
												} while (key > 3);
												claimBean.setPolicyNumber(policyBean.getPolicyNumber());
												try {
													boolean a = iInsuranceService.validateDetails(claimBean);
													if (a == true) 
													{
//														System.out.println("Enter the user name");
//														String name=sc.next();
//														iInsuranceService=new InsuranceServiceImpl();
														String segment=iInsuranceService.getBusinessSegment(name);
														questionBean = new QuestionBean();
														//insuranceServiceImpl = new InsuranceServiceImpl();
														List<QuestionBean> list = new ArrayList<>();
														list = insuranceServiceImpl.getQuestions(segment);
														policyDetailsList = new ArrayList<>();
														
														if (list.isEmpty())
														{
															System.err.println("No questions....");
														}
														else 
														{
															int questionNumber=1;
															ListIterator<QuestionBean> iterator = list.listIterator();
															//Iterator<QuestionBean> iterator = list.iterator();
															while (iterator.hasNext())
															{
																policyDetailsBean = new PolicyDetailsBean();
																QuestionBean questionBean1 = new QuestionBean();
																questionBean1 = iterator.next();
																System.out.println("Q"+questionNumber+" "+questionBean1.getQuestion() + " ?");
																policyDetailsBean.setPolicyNumber(claimBean.getPolicyNumber());
																policyDetailsBean.setQuestionId(questionBean1.getQuestionId());
																System.out.println("1.	" + questionBean1.getAnswer1());
																System.out.println("2.	" + questionBean1.getAnswer2());
																System.out.println("3.	" + questionBean1.getAnswer3());
																int choice;
																System.out.println("Select your answer");
																choice = sc.nextInt();
																switch (choice)
																{
																case 1:

																	weightage = weightage + questionBean1.getAnswerWeightage1();
																	policyDetailsBean.setAnswer(questionBean1.getAnswer1());
																	policyDetailsList.add(policyDetailsBean);
																	break;

																case 2:

																	weightage = weightage + questionBean1.getAnswerWeightage2();
																	policyDetailsBean.setAnswer(questionBean1.getAnswer2());
																	policyDetailsList.add(policyDetailsBean);
																	break;

																case 3:
																	
																	weightage = weightage + questionBean1.getAnswerWeightage3();
																	policyDetailsBean.setAnswer(questionBean1.getAnswer3());
																	policyDetailsList.add(policyDetailsBean);
																	break;	

																default:
																	System.err.println("InputMismatch !!!! Choose Again");
																	questionNumber--;
																	iterator.previous();
																	break;
																}
																
																questionNumber++;
															}
															
															
															if (weightage >= 1600 && weightage <= 2600) {
																claimNo = "A";
																
															}
															else if (weightage > 2600 && weightage <= 3600) {
																claimNo = "B";
																
															} else if (weightage > 3600 && weightage <= 4600) {
																claimNo = "C";
																
															} else if (weightage > 4600 && weightage <= 5600) {
																claimNo = "D";
																	
															} else if (weightage > 5600) {
																claimNo = "E";
																
															} else {
																claimNo = null;
															}
															claimBean.setClaimNumber(claimNo);
															
															
															claimNumber = iInsuranceService.createClaim(claimBean,policyDetailsList);
															System.out.println("Your Claim with ClaimNmber "+claimNumber+"has been successfully created for PolicyNumber "+claimBean.getPolicyNumber());
														}
														
													}
													 
												} catch (InsuranceClaimException e)
												{
													System.err.println(e.getMessage()+" \n");
												}
												 
												
												
												
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////											
											}
											else {
												System.err.println("please Enter Only from above options");
											}
											
										}catch (InputMismatchException e) {
											
											sc.nextLine();
											System.err.println("please enter only numeric value");
										}
										
								
									} else {
										System.err.println("No policies Associated with user.");
									}
								}
								// logger.info("policy list is generated");
							} catch (InsuranceClaimException e) {

								// logger.error("Exception occurred", e);
								System.err.println("ERROR : " + e.getMessage());
							} finally {
								insuranceServiceImpl = null;
								iInsuranceService = null;
								claimBean = null;

							}
						
						
						break;
					case 2:
							//System.out.println("Choose from Below Claims Which You want to see");
							try {
								iInsuranceService = new InsuranceServiceImpl();
								List<ClaimBean> claimList = new ArrayList<ClaimBean>();
//								System.out.println("Enter your User Name Again");
//								String name = sc.next();
//								if (!name.equals(userbean.getUsername())) {
//									System.err.println("Incorrect username!!!!\n   Try Again");
//									
//								} else {
									String name=userbean.getUsername();
									claimList = iInsuranceService.viewAllClaims(name);
									if (!claimList.isEmpty()) {
										Iterator<ClaimBean> i = claimList.iterator();
										int claimNumber=1;
										System.out.println("SNo.\tPolicy Number\tCLaimNumber\tClaim Type");
										while (i.hasNext()) {
											//System.out.println(i.next());
											claimBean = new ClaimBean();
											claimBean=i.next();
											System.out.println(claimNumber+".\t"+claimBean.getPolicyNumber()+"\t\t"+claimBean.getClaimNumber()+"\t\t"+claimBean.getClaimType());
											claimNumber++;
										}

									} else {
										System.out.println("There are No Claims");
									}
									// logger.info("policy is generated");
	//							}//else block of user verification
							} catch (InsuranceClaimException e) {
								
								// logger.error("Exception occurred", e);
								System.err.println("ERROR : "+ e.getMessage());
							}
							finally {
								insuranceServiceImpl=null;
								iInsuranceService=null;
								claimBean=null;
								
							}

						break;
					case 3:
						System.exit(0);
						break;
					default:
						System.err.println("Please Select only from above options");
						break;
					}
					
				}                         
				catch (InputMismatchException e) {
						sc.nextLine();
						System.out.println("Please enter only Numeric Value.");
				}
				finally {
					
				}
		}	
		
	case "agent":
		while(true)
		{
			System.out.println("\n-------------------Welcome Agent----------------\n");
			System.out.println("1.Create Claim for Your Customers.");							//done
			System.out.println("2.View Claim of your Customers.");								//done
			System.out.println("3.Exit.\n");
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
					iInsuranceService = new InsuranceServiceImpl();
					agentUserBean = new AgentUserBean();
					System.out.println("Enter your User Name Again:");
					String name = sc.next();
					
					if (!name.equals(userbean.getUsername())) {
						System.err.println("Please enter correct username!!!!");
						
					} else {
					
						List<AgentUserBean> agentUserList = new ArrayList<>();
						agentUserList=iInsuranceService.fetchUsers(name);
						Iterator<AgentUserBean> a1 = agentUserList.iterator();
						int userNumber=1;
						System.out.println("List of Your Customers are:");
						System.out.println("SNo.\tUserName");
						while (a1.hasNext()) {
							//System.out.println(i.next());
							
							agentUserBean=a1.next();
							System.out.println(userNumber+".\t"+agentUserBean.getUserID());
							userNumber++;
						}
						
/////////////////////////////////////////////////////Choosing from Options and BAsed on that perform task///////////////////////////////////////////////////////////////
						
						System.out.println("\nSelect User for which You Want to Create Claim.");
						//String name=null;
						try {
							int check=sc.nextInt();
							if(check>0&&check<userNumber) {
								int inc=1;
								Iterator<AgentUserBean> a2 = agentUserList.iterator();
								while (inc<=check) {
									agentUserBean = a2.next();
									inc++;
								}
								name=agentUserBean.getUserID();
							}
							else {
								System.err.println("please Enter Only from above options");
							}
							
						}catch (InputMismatchException e) {
							
							sc.nextLine();
							System.err.println("please enter only numeric value");
						}
						
						
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////							
						
					
					// TODO claim creation
					
						List<PolicyBean> policyList = new ArrayList<PolicyBean>();
						policyList = iInsuranceService.viewAllPolicies(name);
						if (!policyList.isEmpty()) {
							int policyNumber = 1;
							Iterator<PolicyBean> i = policyList.iterator();
							System.out.println("Policy List\tAccount Number\tPolicy Number\tPremium Amount");
							while (i.hasNext()) {
								
								policyBean = i.next();
								System.out.println(
										"    " + policyNumber + ".\t\t" + policyBean.getAccountNumber()
												+ "\t\t" + policyBean.getPolicyNumber() + "\t\t"
												+ policyBean.getPolicyPremium());
								policyNumber++;
							}
							
							
							
							
							
							System.out.println("\nSelect option for which You Want to Create Claim.");
							
							
							try {
								int check=sc.nextInt();
								if(check>0&&check<policyNumber) {
									int inc=1;
									Iterator<PolicyBean> i1 = policyList.iterator();
									while (inc<=check) {
										policyBean = i1.next();
										inc++;
									}
									//System.out.println(policyBean.getPolicyNumber());
//////////////////////////////////////////////here claim Creation will come/////////////////////////////////////////////////////////////////
									int weightage = 0;
									String str = null;
									String claimNo = null;
									String claimNumber = null;
									claimBean = new ClaimBean();
									System.out.println("Enter Details To avail Claim");
									
									System.out.println("Enter claim Reason");
									claimBean.setClaimReason(sc.next());
									System.out.println("Enter Accident Location");
									claimBean.setAccidentLocationStreet(sc.next());
									System.out.println("Enter Accident City");
									claimBean.setAccidentCity(sc.next());
									System.out.println("Enter Accident State");
									claimBean.setAccidentState(sc.next());
									System.out.println("Enter Accident Zip");
									claimBean.setAccidentZip(sc.next());
									System.out.println("Choose the below optoin to select the claim type");
									int key = 0;
									loop: do {
										try {

											System.out.println("1.Road Accident Claims");
											System.out.println("2.Medical Negligence Claims");
											System.out.println("3.Trip Accident Claims");

											key = sc.nextInt();
											switch (key) {
											case 1:
												str = "Road Accident Claims";
												claimBean.setClaimType(str);

												break;
											case 2:
												str = "Medical Negligence Claims";
												claimBean.setClaimType(str);

												break;
											case 3:
												str = "Trip Accident Claims";
												claimBean.setClaimType(str);

												break;
											default:

												System.out.println("Please enter from the above options again");
												break;
											}

										} catch (InputMismatchException e) {
											System.out.println(e.getMessage());
											System.out.println("try again...");
											sc.nextLine();
											continue loop;

										}
									} while (key > 3);
									claimBean.setPolicyNumber(policyBean.getPolicyNumber());
									try {
										boolean a = iInsuranceService.validateDetails(claimBean);
										if (a == true) 
										{
//											System.out.println("Enter the user name");
//											String name=sc.next();
//											iInsuranceService=new InsuranceServiceImpl();
											
											String segment=iInsuranceService.getBusinessSegment(name);
											System.out.println(segment);
											questionBean = new QuestionBean();
											insuranceServiceImpl = new InsuranceServiceImpl();
											List<QuestionBean> list = new ArrayList<>();
											list = insuranceServiceImpl.getQuestions(segment);
											policyDetailsList = new ArrayList<>();
											
											if (list.isEmpty())
											{
												System.err.println("No questions....");
											}
											else 
											{
												int questionNumber=1;
												ListIterator<QuestionBean> iterator = list.listIterator();
												//Iterator<QuestionBean> iterator = list.iterator();
												while (iterator.hasNext())
												{
													policyDetailsBean = new PolicyDetailsBean();
													QuestionBean questionBean1 = new QuestionBean();
													questionBean1 = iterator.next();
													System.out.println("Q"+questionNumber+" "+questionBean1.getQuestion() + " ?");
													policyDetailsBean.setPolicyNumber(claimBean.getPolicyNumber());
													policyDetailsBean.setQuestionId(questionBean1.getQuestionId());
													System.out.println("1.	" + questionBean1.getAnswer1());
													System.out.println("2.	" + questionBean1.getAnswer2());
													System.out.println("3.	" + questionBean1.getAnswer3());
													int choice;
													System.out.println("Select your answer");
													choice = sc.nextInt();
													switch (choice)
													{
													case 1:

														weightage = weightage + questionBean1.getAnswerWeightage1();
														policyDetailsBean.setAnswer(questionBean1.getAnswer1());
														policyDetailsList.add(policyDetailsBean);
														break;

													case 2:

														weightage = weightage + questionBean1.getAnswerWeightage2();
														policyDetailsBean.setAnswer(questionBean1.getAnswer2());
														policyDetailsList.add(policyDetailsBean);
														break;

													case 3:
														
														weightage = weightage + questionBean1.getAnswerWeightage3();
														policyDetailsBean.setAnswer(questionBean1.getAnswer3());
														policyDetailsList.add(policyDetailsBean);
														break;	

													default:
														System.err.println("InputMismatch !!!! Choose Again");
														questionNumber--;
														iterator.previous();
														break;
													}
													
													questionNumber++;
												}
												
												
												if (weightage >= 1600 && weightage <= 2600) {
													claimNo = "A";
													
												}
												else if (weightage > 2600 && weightage <= 3600) {
													claimNo = "B";
													
												} else if (weightage > 3600 && weightage <= 4600) {
													claimNo = "C";
													
												} else if (weightage > 4600 && weightage <= 5600) {
													claimNo = "D";
														
												} else if (weightage > 5600) {
													claimNo = "E";
													
												} else {
													claimNo = null;
												}
												claimBean.setClaimNumber(claimNo);
												
												
												claimNumber = iInsuranceService.createClaim(claimBean,policyDetailsList);
												System.out.println("Your Claim with ClaimNmber "+claimNumber+"has been successfully created for PolicyNumber "+claimBean.getPolicyNumber());
											}
											
										}
										 
									} catch (InsuranceClaimException e)
									{
										System.err.println(e.getMessage()+" \n");
									}
									 
									
									
									
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////											
								}
								else {
									System.err.println("please Enter Only from above options");
								}
								
							}catch (InputMismatchException e) {
								
								sc.nextLine();
								System.err.println("please enter only numeric value");
							}
							
					
						} else {
							System.err.println("No policies Associated with user.");
						}
					
					
					
					
						
						
						
						
						
						
						
						
						
						
						
						
						
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////						
					}
					break;
				case 2:
					try {
						iInsuranceService = new InsuranceServiceImpl();
						agentUserBean = new AgentUserBean();
						System.out.println("Enter your User Name Again:");
						name = sc.next();
						
						if (!name.equals(userbean.getUsername())) {
							System.err.println("Please enter correct username!!!!");
							
						} else {
							List<AgentUserBean> agentUserList = new ArrayList<>();
							agentUserList=iInsuranceService.fetchUsers(name);
							Iterator<AgentUserBean> a1 = agentUserList.iterator();
							int userNumber=1;
							System.out.println("List of Your Customers are:");
							System.out.println("SNo.\tUserName");
							while (a1.hasNext()) {
								//System.out.println(i.next());
								
								agentUserBean=a1.next();
								System.out.println(userNumber+".\t"+agentUserBean.getUserID());
								userNumber++;
							}
							
/////////////////////////////////////////////////////Choosing from Options and BAsed on that perform task///////////////////////////////////////////////////////////////
							
							System.out.println("\nSelect option for which You Want to View Claim.");
							String name1=null;
							try {
								int check=sc.nextInt();
								if(check>0&&check<userNumber) {
									int inc=1;
									Iterator<AgentUserBean> a2 = agentUserList.iterator();
									while (inc<=check) {
										agentUserBean = a2.next();
										inc++;
									}
									name1=agentUserBean.getUserID();
								}
								else {
									System.err.println("please Enter Only from above options");
								}
								
							}catch (InputMismatchException e) {
								
								sc.nextLine();
								System.err.println("please enter only numeric value");
							}
							
							
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////							
							if(name1!=null) {
							List<ClaimBean> claimList = new ArrayList<ClaimBean>();
							claimList = iInsuranceService.viewAllClaims(name1);
							if (!claimList.isEmpty()) {
								Iterator<ClaimBean> i = claimList.iterator();
								int claimNumber=1;
								System.out.println("SNo.\tPolicy Number\tCLaimNumber\tClaim Type");
								while (i.hasNext()) {
									//System.out.println(i.next());
									claimBean = new ClaimBean();
									claimBean=i.next();
									System.out.println(claimNumber+".\t"+claimBean.getPolicyNumber()+"\t\t"+claimBean.getClaimNumber()+"\t\t"+claimBean.getClaimType());
									claimNumber++;
								}

							} else {
								System.out.println("There are No Claims");
							}
							// logger.info("policy is generated");
						}
						}
					} catch (InsuranceClaimException e) {
						
						// logger.error("Exception occured", e);
						System.err.println("ERROR : "+ e.getMessage());
					}
					finally {
						insuranceServiceImpl=null;
						iInsuranceService=null;
						claimBean=null;
						
					}
					break;
				case 3:
					System.exit(0);
					break;
				default:
					System.err.println("Please Select only from above options");
					break;
				}
			}                         
			catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("Please enter only Numeric Value.");
			}   
	    }	
		
	case "admin":
		while(true)
		{
			System.out.println("\n-------------------Welcome Admin----------------\n");
			System.out.println("1.Create Profile.");									//done
			System.out.println("2.Create Claim for any customer.");						 								//done
			System.out.println("3.View Claim of any customer.");						//done
			System.out.println("4.Generate Report.");																	//not done
			System.out.println("5.Exit.\n");
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
						userbean=null;
						while(userbean==null) {
						userbean = populateUserBean();
						}
						try {
							iInsuranceService = new InsuranceServiceImpl(); 
							iInsuranceService.addUser(userbean);
							
							System.out.println("User Profile has been Succcessfully Created !!!! ");

						} catch (InsuranceClaimException insuranceException) {
							
							System.err.println("ERROR : "+ insuranceException.getMessage());
						} finally {
							userbean = null;
							iInsuranceService = null;
							
						}
						
					break;
				case 2:
					try {
						iInsuranceService = new InsuranceServiceImpl();
						insuranceServiceImpl = new InsuranceServiceImpl();
						policyBean = new PolicyBean();
						List<PolicyBean> policyList = new ArrayList<PolicyBean>();
						System.out.println("Enter the name of User for which you want to Create Claim: ");
						String name = sc.next();
						
							policyList = iInsuranceService.viewAllPolicies(name);
							if (!policyList.isEmpty()) {
								int policyNumber = 1;
								Iterator<PolicyBean> i = policyList.iterator();
								System.out.println("Policy List\tAccount Number\tPolicy Number\tPremium Amount");
								while (i.hasNext()) {
									
									policyBean = i.next();
									System.out.println(
											"    " + policyNumber + ".\t\t" + policyBean.getAccountNumber()
													+ "\t\t" + policyBean.getPolicyNumber() + "\t\t"
													+ policyBean.getPolicyPremium());
									policyNumber++;
								}
								
								
								
								
								
								System.out.println("\nSelect option for which You Want to Create Claim.");
								
								
								try {
									int check=sc.nextInt();
									if(check>0&&check<policyNumber) {
										int inc=1;
										Iterator<PolicyBean> i1 = policyList.iterator();
										while (inc<=check) {
											policyBean = i1.next();
											inc++;
										}
										System.out.println(policyBean);
//////////////////////////////////////////////here claim Creation will come/////////////////////////////////////////////////////////////////
										
										
										
										//TODO 
										
										int weightage = 0;
										String str = null;
										String claimNo = null;
										String claimNumber = null;
										claimBean = new ClaimBean();
										System.out.println("Enter Details To avail Claim");
										
										System.out.println("Enter claim Reason");
										claimBean.setClaimReason(sc.next());
										System.out.println("Enter Accident Location");
										claimBean.setAccidentLocationStreet(sc.next());
										System.out.println("Enter Accident City");
										claimBean.setAccidentCity(sc.next());
										System.out.println("Enter Accident State");
										claimBean.setAccidentState(sc.next());
										System.out.println("Enter Accident Zip");
										claimBean.setAccidentZip(sc.next());
										System.out.println("Choose the below optoin to select the claim type");
										int key = 0;
										loop: do {
											try {

												System.out.println("1.Road Accident Claims");
												System.out.println("2.Medical Negligence Claims");
												System.out.println("3.Trip Accident Claims");

												key = sc.nextInt();
												switch (key) {
												case 1:
													str = "Road Accident Claims";
													claimBean.setClaimType(str);

													break;
												case 2:
													str = "Medical Negligence Claims";
													claimBean.setClaimType(str);

													break;
												case 3:
													str = "Trip Accident Claims";
													claimBean.setClaimType(str);

													break;
												default:

													System.out.println("Please enter from the above options again");
													break;
												}

											} catch (InputMismatchException e) {
												System.out.println(e.getMessage());
												System.out.println("try again...");
												sc.nextLine();
												continue loop;

											}
										} while (key > 3);
										claimBean.setPolicyNumber(policyBean.getPolicyNumber());
										try {
											boolean a = iInsuranceService.validateDetails(claimBean);
											if (a == true) 
											{
//												System.out.println("Enter the user name");
//												String name=sc.next();
//												iInsuranceService=new InsuranceServiceImpl();
												
												String segment=iInsuranceService.getBusinessSegment(name);
												System.out.println(segment);
												questionBean = new QuestionBean();
												insuranceServiceImpl = new InsuranceServiceImpl();
												List<QuestionBean> list = new ArrayList<>();
												list = insuranceServiceImpl.getQuestions(segment);
												policyDetailsList = new ArrayList<>();
												
												if (list.isEmpty())
												{
													System.err.println("No questions....");
												}
												else 
												{
													int questionNumber=1;
													ListIterator<QuestionBean> iterator = list.listIterator();
													//Iterator<QuestionBean> iterator = list.iterator();
													while (iterator.hasNext())
													{
														policyDetailsBean = new PolicyDetailsBean();
														QuestionBean questionBean1 = new QuestionBean();
														questionBean1 = iterator.next();
														System.out.println("Q"+questionNumber+" "+questionBean1.getQuestion() + " ?");
														policyDetailsBean.setPolicyNumber(claimBean.getPolicyNumber());
														policyDetailsBean.setQuestionId(questionBean1.getQuestionId());
														System.out.println("1.	" + questionBean1.getAnswer1());
														System.out.println("2.	" + questionBean1.getAnswer2());
														System.out.println("3.	" + questionBean1.getAnswer3());
														int choice;
														System.out.println("Select your answer");
														choice = sc.nextInt();
														switch (choice)
														{
														case 1:

															weightage = weightage + questionBean1.getAnswerWeightage1();
															policyDetailsBean.setAnswer(questionBean1.getAnswer1());
															policyDetailsList.add(policyDetailsBean);
															break;

														case 2:

															weightage = weightage + questionBean1.getAnswerWeightage2();
															policyDetailsBean.setAnswer(questionBean1.getAnswer2());
															policyDetailsList.add(policyDetailsBean);
															break;

														case 3:
															
															weightage = weightage + questionBean1.getAnswerWeightage3();
															policyDetailsBean.setAnswer(questionBean1.getAnswer3());
															policyDetailsList.add(policyDetailsBean);
															break;	

														default:
															System.err.println("InputMismatch !!!! Choose Again");
															questionNumber--;
															iterator.previous();
															break;
														}
														
														questionNumber++;
													}
													
													
													if (weightage >= 1600 && weightage <= 2600) {
														claimNo = "A";
														
													}
													else if (weightage > 2600 && weightage <= 3600) {
														claimNo = "B";
														
													} else if (weightage > 3600 && weightage <= 4600) {
														claimNo = "C";
														
													} else if (weightage > 4600 && weightage <= 5600) {
														claimNo = "D";
															
													} else if (weightage > 5600) {
														claimNo = "E";
														
													} else {
														claimNo = null;
													}
													claimBean.setClaimNumber(claimNo);
													
													
													claimNumber = iInsuranceService.createClaim(claimBean,policyDetailsList);
													System.out.println("Your Claim with ClaimNmber "+claimNumber+"has been successfully created for PolicyNumber "+claimBean.getPolicyNumber());
												}
												
											}
											 
										} catch (InsuranceClaimException e)
										{
											System.err.println(e.getMessage()+" \n");
										}
										
										
										
										
										
										
										
										
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////											
									}
									else {
										System.err.println("please Enter Only from above options");
									}
									
								}catch (InputMismatchException e) {
									
									sc.nextLine();
									System.err.println("please enter only numeric value");
								}
								
						
							} else {
								System.err.println("No policies Associated with user.");
							}
						
						// logger.info("policy list is generated");
					} catch (InsuranceClaimException e) {

						// logger.error("Exception occurred", e);
						System.err.println("ERROR : " + e.getMessage());
					} finally {
						insuranceServiceImpl = null;
						iInsuranceService = null;
						claimBean = null;

					}
					
					break;
				case 3:
					try {
						iInsuranceService = new InsuranceServiceImpl();
						List<ClaimBean> claimList = new ArrayList<ClaimBean>();
						System.out.println("Enter UserName to view Claims of Customer");
						String name = sc.next();
							claimList = iInsuranceService.viewAllClaims(name);
							if (!claimList.isEmpty()) {
								Iterator<ClaimBean> i = claimList.iterator();
								int claimNumber=1;
								System.out.println("SNo.\tPolicy Number\tCLaimNumber\tClaim Type");
								while (i.hasNext()) {
									//System.out.println(i.next());
									claimBean = new ClaimBean();
									claimBean=i.next();
									System.out.println(claimNumber+".\t"+claimBean.getPolicyNumber()+"\t\t"+claimBean.getClaimNumber()+"\t\t"+claimBean.getClaimType());
									claimNumber++;
								}

							} else {
								System.out.println("There are No Claims");
							}
							// logger.info("policy is generated");
						
					} catch (InsuranceClaimException e) {
						
						// logger.error("Exception occurred", e);
						System.err.println("ERROR : "+ e.getMessage());
					}
					finally {
						insuranceServiceImpl=null;
						iInsuranceService=null;
						claimBean=null;
						
					}
						
					break;
				case 4:
	
					break;
				case 5:
					System.exit(0);
					break;
				default:
					System.err.println("Please Select only from above options");
					break;
				}
			}                         
			catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("Please enter only Numeric Value.");
			}   
	}	
	default:
		System.out.println("Please Select only from above options");
		break;
	}
	
	}
	
}

private static UserBean populateUserBean() {
	userbean = new UserBean();
	System.out.println("-------------\tProfile Creation Menu\t--------------------\n");
	System.out.println("Enter Details:\n");
	System.out.println("Enter Username U want to give: ");
	userbean.setUsername(sc.next());
	System.out.println("Enter Password that u want to give: ");
	userbean.setPassword(sc.next());
	System.out.println("Select from below Roles for which you want to create profile:");
	System.out.println("1.Insured");
	System.out.println("2.Agent");
	System.out.println("3.Admin");
	try {
		String roleCode=null;
		int option = sc.nextInt();
		switch (option) {
		case 1:
			roleCode="Insured";
			break;
		case 2:
			roleCode="Agent";	
			break;
		case 3:
			roleCode="Admin";	
			break;
		default:
			System.err.println("Select Only from Above Option\n");
			break;
		}
		userbean.setRoleCode(roleCode);
		if(roleCode!=null) {
			insuranceServiceImpl=new InsuranceServiceImpl();
			try {
				insuranceServiceImpl.validateUserDetails(userbean);
				return userbean;
			} catch(InsuranceClaimException insuranceException) {
				
				System.err.println("Invalid data:");
				System.err.println(insuranceException.getMessage() + " \n Want to Try again..????(y/n)");
				String cond=sc.next();
				if(!(cond.equals("y")||cond.equals("Y"))) {
					System.exit(0);
				}

			}
			
		}
		
	} catch (InputMismatchException inputMismatchException) {
		sc.nextLine();
		System.err.println("Please enter a numeric value for Roles");
		}
	return null;
}
}
