package com.cg.insurance.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;



public interface IInsuranceDAO {
	

	String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException;

	void addUser(UserBean userbean) throws InsuranceClaimException, IOException;

	List<ClaimBean> viewAllClaims(String name) throws InsuranceClaimException, IOException, SQLException;

	List<PolicyBean> viewAllPolicy(String name) throws IOException, InsuranceClaimException, SQLException;

	List<AgentUserBean> fetchUsers(String name) throws IOException, InsuranceClaimException, SQLException;

	public String createClaim(ClaimBean claimBean, List<PolicyDetailsBean> policyDetailsList) throws ClassNotFoundException, SQLException, Exception;
	public List<QuestionBean> getQuestions(String businessSegment) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException;
	public String getBusinessSegment(String name) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException;
}
